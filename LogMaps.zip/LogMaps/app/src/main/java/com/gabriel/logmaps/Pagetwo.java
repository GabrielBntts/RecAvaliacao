package com.gabriel.logmaps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.IMapViewDelegate;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class Pagetwo extends AppCompatActivity {

    private Button btnVoltar;
    private  TextView edtName,edtPhone,edtEmail,edtTxt;
    private MapView mapView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagetwo);



        Intent intent = getIntent();

        TextView edtName = (TextView) findViewById(R.id.text_name);
        edtName.setText("Oi " + intent.getStringExtra(PageOne.EXTRA_NAME)+"!");

        TextView edtPhone = (TextView) findViewById(R.id.text_phone);
        edtPhone.setText("Seu Telefone é: " + intent.getStringExtra(PageOne.EXTRA_PHONE));

        TextView edtEmail = (TextView) findViewById(R.id.text_email);
        edtEmail.setText("Seu email é: " + intent.getStringExtra(PageOne.EXTRA_EMAIL));

        TextView edtTxt = (TextView) findViewById(R.id.text_texto);
        edtTxt.setText("Prazer, mostre a sua casa: ");

         Button btnVoltar = (Button) findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(this::onClick);


    }



    private void onClick(View view) {
        Intent intent = new Intent(this, MainActivity.class);

        startActivity(intent);
    }


}